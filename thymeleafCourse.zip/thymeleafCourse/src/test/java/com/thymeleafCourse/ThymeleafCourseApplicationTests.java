package com.thymeleafCourse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafCourseApplicationTests {

	@Test
	void contextLoads() {
	}

}
