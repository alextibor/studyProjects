package com.example.handlingformsubmission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandlingFormSubmissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
